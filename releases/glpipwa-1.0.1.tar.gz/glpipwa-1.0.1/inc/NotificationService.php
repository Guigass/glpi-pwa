<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2024 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * Serviço centralizado de notificações
 * Responsável por coletar envolvidos, montar payloads e enviar notificações
 */
class PluginGlpipwaNotificationService
{
    /**
     * Arquivo de log para notificações
     */
    private const LOG_FILE = 'plugin-notify.log';

    /**
     * Método principal para enviar notificações
     * 
     * @param int $ticketId ID do ticket
     * @param string $eventType Tipo do evento (ticket_created, ticket_updated, etc.)
     * @param array $payload Dados adicionais para o payload
     * @param int|null $excludeUserId ID do usuário a ser excluído (autor da ação)
     * @return void
     */
    public static function notify($ticketId, string $eventType, array $payload, ?int $excludeUserId = null): void
    {
        try {
            // Verificar se Firebase está configurado
            if (!class_exists('PluginGlpipwaConfig')) {
                self::log('warning', "PluginGlpipwaConfig não encontrado");
                return;
            }

            $config = PluginGlpipwaConfig::getAll();
            if (!PluginGlpipwaConfig::validateFirebaseConfig($config)) {
                self::log('warning', "Firebase não está configurado corretamente");
                return;
            }

            // Coletar destinatários
            $recipients = self::collectTicketRecipients($ticketId, $excludeUserId);

            if (empty($recipients)) {
                return;
            }

            // Montar título e corpo baseado no tipo de evento
            $title = self::buildTitle($eventType, $ticketId, $payload);
            $body = self::buildBody($eventType, $ticketId, $payload);

            // Montar payload completo
            $fullPayload = self::buildPayload($eventType, $ticketId, $payload);

            // Enviar notificação
            if (!class_exists('PluginGlpipwaNotificationPush')) {
                self::log('error', "PluginGlpipwaNotificationPush não encontrado");
                return;
            }

            $notificationPush = new PluginGlpipwaNotificationPush();
            $notificationPush->sendToUsers($recipients, $title, $body, $fullPayload);

            self::log('info', "Notificação enviada para ticket ID: {$ticketId}, evento: {$eventType}, destinatários: " . count($recipients));

        } catch (Exception $e) {
            self::log('error', "Erro ao enviar notificação: " . $e->getMessage(), [
                'ticket_id' => $ticketId,
                'event_type' => $eventType,
                'trace' => $e->getTraceAsString()
            ]);
            
            // Também logar via Toolbox para garantir visibilidade
            if (class_exists('Toolbox')) {
                Toolbox::logInFile('glpipwa', "GLPI PWA NotificationService: Erro fatal ao enviar notificação: " . $e->getMessage(), LOG_ERR);
            }
        } catch (Throwable $e) {
            self::log('error', "Erro fatal ao enviar notificação: " . $e->getMessage(), [
                'ticket_id' => $ticketId,
                'event_type' => $eventType,
                'trace' => $e->getTraceAsString()
            ]);
            
            // Também logar via Toolbox para garantir visibilidade
            if (class_exists('Toolbox')) {
                Toolbox::logInFile('glpipwa', "GLPI PWA NotificationService: Erro fatal ao enviar notificação: " . $e->getMessage(), LOG_ERR);
            }
        }
    }

    /**
     * Coleta todos os envolvidos de um ticket
     * 
     * @param int $ticketId ID do ticket
     * @param int|null $excludeUserId ID do usuário a ser excluído
     * @return array Lista de IDs de usuários
     */
    private static function collectTicketRecipients($ticketId, ?int $excludeUserId = null): array
    {
        $recipients = [];


        if (!class_exists('Ticket')) {
            self::log('warning', "Classe Ticket não existe");
            return $recipients;
        }

        try {
            $ticket = new Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                self::log('warning', "Ticket ID {$ticketId} não encontrado no banco de dados");
                return $recipients;
            }

            self::log('debug', "Ticket ID {$ticketId} carregado com sucesso");

            // Técnico designado
            $tech_id = $ticket->getField('users_id_tech');
            if (self::isValidUserId($tech_id)) {
                $recipients[] = (int)$tech_id;
                self::log('debug', "Técnico designado encontrado: user_id={$tech_id} para ticket ID: {$ticketId}");
            } else {
                self::log('debug', "Técnico designado não encontrado ou inválido (users_id_tech={$tech_id}) para ticket ID: {$ticketId}");
            }

            // Grupo técnico
            $tech_group = $ticket->getField('groups_id_tech');
            if ($tech_group > 0 && class_exists('Group') && class_exists('Group_User')) {
                try {
                    $group = new Group();
                    if ($group->getFromDB($tech_group)) {
                        $groupUsers = Group_User::getGroupUsers($tech_group);
                        self::log('debug', "Grupo técnico encontrado: group_id={$tech_group}, usuários no grupo: " . count($groupUsers) . " para ticket ID: {$ticketId}");
                        foreach ($groupUsers as $user) {
                            $user_id = $user['id'] ?? null;
                            if (self::isValidUserId($user_id)) {
                                $recipients[] = (int)$user_id;
                                self::log('debug', "Usuário do grupo técnico encontrado: user_id={$user_id} para ticket ID: {$ticketId}");
                            }
                        }
                    } else {
                        self::log('warning', "Grupo técnico ID {$tech_group} não encontrado no banco de dados para ticket ID: {$ticketId}");
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter usuários do grupo técnico (group_id={$tech_group}): " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter usuários do grupo técnico (group_id={$tech_group}): " . $e->getMessage());
                }
            } else {
                self::log('debug', "Grupo técnico não configurado (groups_id_tech={$tech_group}) para ticket ID: {$ticketId}");
            }

            // Observadores via Ticket_User
            if (class_exists('Ticket_User') && class_exists('CommonITILActor')) {
                try {
                    $OBSERVER_TYPE = self::getActorTypeConstant('OBSERVER');
                    if ($OBSERVER_TYPE === null) {
                        $OBSERVER_TYPE = 3;
                    }
                    
                    $ticket_user = new Ticket_User();
                    $observers = $ticket_user->find([
                        'tickets_id' => $ticketId,
                        'type' => $OBSERVER_TYPE
                    ]);
                    
                    self::log('debug', "Buscando observadores (type={$OBSERVER_TYPE}) para ticket ID: {$ticketId}, encontrados: " . count($observers));
                    
                    foreach ($observers as $obs) {
                        $user_id = $obs['users_id'] ?? null;
                        if (self::isValidUserId($user_id)) {
                            $recipients[] = (int)$user_id;
                            self::log('debug', "Observador encontrado: user_id={$user_id} para ticket ID: {$ticketId}");
                        }
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter observadores: " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter observadores: " . $e->getMessage());
                }
            }

            // Solicitantes via Ticket_User
            if (class_exists('Ticket_User') && class_exists('CommonITILActor')) {
                try {
                    $REQUESTER_TYPE = self::getActorTypeConstant('REQUESTER');
                    if ($REQUESTER_TYPE === null) {
                        $REQUESTER_TYPE = 1;
                    }
                    
                    $ticket_user = new Ticket_User();
                    $requesters = $ticket_user->find([
                        'tickets_id' => $ticketId,
                        'type' => $REQUESTER_TYPE
                    ]);
                    
                    self::log('debug', "Buscando solicitantes (type={$REQUESTER_TYPE}) para ticket ID: {$ticketId}, encontrados: " . count($requesters));
                    
                    foreach ($requesters as $req) {
                        $user_id = $req['users_id'] ?? null;
                        if (self::isValidUserId($user_id)) {
                            $recipients[] = (int)$user_id;
                            self::log('debug', "Solicitante encontrado: user_id={$user_id} para ticket ID: {$ticketId}");
                        }
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter solicitantes: " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter solicitantes: " . $e->getMessage());
                }
            }

            // Técnicos via Ticket_User (ASSIGN)
            if (class_exists('Ticket_User') && class_exists('CommonITILActor')) {
                try {
                    // Obter valor da constante ASSIGN com fallback seguro
                    $ASSIGN_TYPE = self::getActorTypeConstant('ASSIGN');
                    if ($ASSIGN_TYPE === null) {
                        // Se não conseguir obter, usar valor numérico padrão (2)
                        $ASSIGN_TYPE = 2;
                    }
                    
                    $ticket_user = new Ticket_User();
                    $assigned = $ticket_user->find([
                        'tickets_id' => $ticketId,
                        'type' => $ASSIGN_TYPE
                    ]);
                    
                    self::log('debug', "Buscando técnicos atribuídos (type={$ASSIGN_TYPE}) para ticket ID: {$ticketId}, encontrados: " . count($assigned));
                    
                    foreach ($assigned as $ass) {
                        $user_id = $ass['users_id'] ?? null;
                        if (self::isValidUserId($user_id)) {
                            $recipients[] = (int)$user_id;
                            self::log('debug', "Técnico atribuído encontrado: user_id={$user_id} para ticket ID: {$ticketId}");
                        }
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter técnicos atribuídos: " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter técnicos atribuídos: " . $e->getMessage());
                }
            }

            // Grupos de observadores via Group_Ticket
            if (class_exists('Group_Ticket') && class_exists('CommonITILActor') && class_exists('Group_User')) {
                try {
                    $OBSERVER_TYPE = self::getActorTypeConstant('OBSERVER');
                    if ($OBSERVER_TYPE === null) {
                        $OBSERVER_TYPE = 3;
                    }
                    
                    $group_ticket = new Group_Ticket();
                    $observerGroups = $group_ticket->find([
                        'tickets_id' => $ticketId,
                        'type' => $OBSERVER_TYPE
                    ]);
                    
                    self::log('debug', "Buscando grupos de observadores (type={$OBSERVER_TYPE}) para ticket ID: {$ticketId}, encontrados: " . count($observerGroups));
                    
                    foreach ($observerGroups as $groupTicket) {
                        $group_id = $groupTicket['groups_id'] ?? null;
                        if ($group_id > 0 && class_exists('Group')) {
                            try {
                                $group = new Group();
                                if ($group->getFromDB($group_id)) {
                                    $groupUsers = Group_User::getGroupUsers($group_id);
                                    self::log('debug', "Grupo de observadores encontrado: group_id={$group_id}, usuários no grupo: " . count($groupUsers) . " para ticket ID: {$ticketId}");
                                    foreach ($groupUsers as $user) {
                                        $user_id = $user['id'] ?? null;
                                        if (self::isValidUserId($user_id)) {
                                            $recipients[] = (int)$user_id;
                                            self::log('debug', "Usuário do grupo de observadores encontrado: user_id={$user_id} (grupo {$group_id}) para ticket ID: {$ticketId}");
                                        }
                                    }
                                }
                            } catch (Exception $e) {
                                self::log('warning', "Erro ao obter usuários do grupo de observadores (group_id={$group_id}): " . $e->getMessage());
                            } catch (Throwable $e) {
                                self::log('error', "Erro fatal ao obter usuários do grupo de observadores (group_id={$group_id}): " . $e->getMessage());
                            }
                        }
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter grupos de observadores: " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter grupos de observadores: " . $e->getMessage());
                }
            }

            // Grupos atribuídos via Group_Ticket (ASSIGN)
            if (class_exists('Group_Ticket') && class_exists('CommonITILActor') && class_exists('Group_User')) {
                try {
                    $ASSIGN_TYPE = self::getActorTypeConstant('ASSIGN');
                    if ($ASSIGN_TYPE === null) {
                        $ASSIGN_TYPE = 2;
                    }
                    
                    $group_ticket = new Group_Ticket();
                    $assignedGroups = $group_ticket->find([
                        'tickets_id' => $ticketId,
                        'type' => $ASSIGN_TYPE
                    ]);
                    
                    self::log('debug', "Buscando grupos atribuídos (type={$ASSIGN_TYPE}) para ticket ID: {$ticketId}, encontrados: " . count($assignedGroups));
                    
                    foreach ($assignedGroups as $groupTicket) {
                        $group_id = $groupTicket['groups_id'] ?? null;
                        if ($group_id > 0 && class_exists('Group')) {
                            try {
                                $group = new Group();
                                if ($group->getFromDB($group_id)) {
                                    $groupUsers = Group_User::getGroupUsers($group_id);
                                    self::log('debug', "Grupo atribuído encontrado: group_id={$group_id}, usuários no grupo: " . count($groupUsers) . " para ticket ID: {$ticketId}");
                                    foreach ($groupUsers as $user) {
                                        $user_id = $user['id'] ?? null;
                                        if (self::isValidUserId($user_id)) {
                                            $recipients[] = (int)$user_id;
                                            self::log('debug', "Usuário do grupo atribuído encontrado: user_id={$user_id} (grupo {$group_id}) para ticket ID: {$ticketId}");
                                        }
                                    }
                                }
                            } catch (Exception $e) {
                                self::log('warning', "Erro ao obter usuários do grupo atribuído (group_id={$group_id}): " . $e->getMessage());
                            } catch (Throwable $e) {
                                self::log('error', "Erro fatal ao obter usuários do grupo atribuído (group_id={$group_id}): " . $e->getMessage());
                            }
                        }
                    }
                } catch (Exception $e) {
                    self::log('warning', "Erro ao obter grupos atribuídos: " . $e->getMessage());
                } catch (Throwable $e) {
                    self::log('error', "Erro fatal ao obter grupos atribuídos: " . $e->getMessage());
                }
            }

            // Remover duplicatas - garante que se um usuário está atribuído individualmente E pertence a um grupo,
            // ele receberá apenas 1 notificação
            $recipients = array_unique($recipients);
            self::log('debug', "Destinatários únicos coletados antes da exclusão: " . count($recipients) . " para ticket ID: {$ticketId}");

            // Remover usuário excluído se especificado
            if ($excludeUserId !== null && $excludeUserId > 0) {
                $beforeExclusion = count($recipients);
                $recipients = array_filter($recipients, function($id) use ($excludeUserId) {
                    return $id != $excludeUserId;
                });
                $afterExclusion = count($recipients);
                if ($beforeExclusion != $afterExclusion) {
                    self::log('debug', "Usuário excluído: user_id={$excludeUserId}, destinatários antes: {$beforeExclusion}, depois: {$afterExclusion} para ticket ID: {$ticketId}");
                }
            }

            // Filtrar para garantir que todos são válidos
            $finalRecipients = self::filterValidUserIds($recipients);
            self::log('debug', "Total de destinatários finais para ticket ID: {$ticketId}: " . count($finalRecipients) . " - IDs: " . implode(', ', $finalRecipients));
            
            return $finalRecipients;

        } catch (Exception $e) {
            self::log('error', "Erro ao coletar destinatários para ticket ID {$ticketId}: " . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return [];
        } catch (Throwable $e) {
            self::log('error', "Erro fatal ao coletar destinatários para ticket ID {$ticketId}: " . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return [];
        }
    }

    /**
     * Monta o payload completo para a notificação
     * 
     * @param string $eventType Tipo do evento
     * @param int $ticketId ID do ticket
     * @param array $additionalData Dados adicionais
     * @return array Payload completo
     */
    private static function buildPayload(string $eventType, int $ticketId, array $additionalData = []): array
    {
        // Gerar ID único para cada notificação (timestamp + ticket_id + event_type)
        // Isso garante que cada notificação tenha um tag único e não substitua outras
        $notificationId = time() . '_' . $ticketId . '_' . $eventType . '_' . mt_rand(1000, 9999);
        
        $payload = [
            'ticket_id' => (string)$ticketId,
            'type' => $eventType,
            'notification_id' => $notificationId, // ID único para evitar substituição de notificações
        ];

        // Adicionar URL do ticket se não estiver presente
        if (!isset($additionalData['url'])) {
            $payload['url'] = self::getTicketUrl($ticketId);
        } else {
            $payload['url'] = $additionalData['url'];
        }

        // Mesclar dados adicionais (convertendo todos para string para FCM)
        foreach ($additionalData as $key => $value) {
            if ($key !== 'url') { // URL já foi tratada
                $payload[$key] = (string)$value;
            }
        }

        self::log('debug', "Payload montado para ticket ID: {$ticketId}, evento: {$eventType}, notification_id: {$notificationId}");

        return $payload;
    }

    /**
     * Constrói o título da notificação baseado no tipo de evento
     * 
     * @param string $eventType Tipo do evento
     * @param int $ticketId ID do ticket
     * @param array $payload Dados adicionais
     * @return string Título da notificação
     */
    private static function buildTitle(string $eventType, int $ticketId, array $payload = []): string
    {
        switch ($eventType) {
            case 'ticket_created':
                return sprintf(__('New Ticket #%d', 'glpipwa'), $ticketId);
            
            case 'ticket_updated':
                return sprintf(__('Ticket #%d Updated', 'glpipwa'), $ticketId);
            
            case 'followup_added':
                return sprintf(__('New interaction on Ticket #%d', 'glpipwa'), $ticketId);
            
            case 'actor_added':
                return sprintf(__('Ticket #%d - New participant', 'glpipwa'), $ticketId);
            
            case 'actor_updated':
                return sprintf(__('Ticket #%d - Participant updated', 'glpipwa'), $ticketId);
            
            case 'validation_added':
                return sprintf(__('Ticket #%d - Validation requested', 'glpipwa'), $ticketId);
            
            case 'validation_updated':
                return sprintf(__('Ticket #%d - Validation updated', 'glpipwa'), $ticketId);
            
            case 'task_added':
                return sprintf(__('Ticket #%d - New task', 'glpipwa'), $ticketId);
            
            default:
                return sprintf(__('Ticket #%d', 'glpipwa'), $ticketId);
        }
    }

    /**
     * Sanitiza conteúdo HTML removendo tags e decodificando entidades
     * 
     * @param string $content Conteúdo a ser sanitizado
     * @return string Conteúdo sanitizado
     */
    private static function sanitizeContent(string $content): string
    {
        try {
            // Remover todas as tags HTML
            $content = strip_tags($content);
            // Decodificar entidades HTML (como &nbsp;, &lt;, etc.)
            $content = html_entity_decode($content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            // Normalizar espaços em branco (múltiplos espaços viram um só)
            $content = preg_replace('/\s+/', ' ', $content);
            // Remover espaços no início e fim
            return trim($content);
        } catch (Exception $e) {
            // Em caso de erro, retornar conteúdo original sem tags
            return strip_tags($content);
        } catch (Throwable $e) {
            // Em caso de erro fatal, retornar conteúdo original sem tags
            return strip_tags($content);
        }
    }

    /**
     * Constrói o corpo da notificação baseado no tipo de evento
     * 
     * @param string $eventType Tipo do evento
     * @param int $ticketId ID do ticket
     * @param array $payload Dados adicionais
     * @return string Corpo da notificação
     */
    private static function buildBody(string $eventType, int $ticketId, array $payload = []): string
    {
        switch ($eventType) {
            case 'ticket_created':
                $name = $payload['ticket_name'] ?? '';
                if ($name) {
                    return $name;
                }
                return __('New ticket opened', 'glpipwa');
            
            case 'ticket_updated':
                return __('The ticket has been updated', 'glpipwa');
            
            case 'followup_added':
                $author = $payload['author_name'] ?? __('User', 'glpipwa');
                $content = $payload['content'] ?? '';
                // Sanitizar conteúdo HTML antes de criar preview
                $content = self::sanitizeContent($content);
                $preview = !empty($content) ? substr($content, 0, 100) : '';
                if ($preview) {
                    return sprintf(__('%s commented: %s', 'glpipwa'), $author, $preview);
                }
                return sprintf(__('%s added a comment', 'glpipwa'), $author);
            
            case 'actor_added':
                $actorName = $payload['actor_name'] ?? __('User', 'glpipwa');
                $actorType = $payload['actor_type'] ?? __('participant', 'glpipwa');
                return sprintf(__('%s was added as %s', 'glpipwa'), $actorName, $actorType);
            
            case 'actor_updated':
                $actorName = $payload['actor_name'] ?? __('User', 'glpipwa');
                return sprintf(__('The participation of %s was updated', 'glpipwa'), $actorName);
            
            case 'validation_added':
                return __('A validation has been requested for this ticket', 'glpipwa');
            
            case 'validation_updated':
                $validator = $payload['validator_name'] ?? __('User', 'glpipwa');
                $status = $payload['status'] ?? 'updated';
                if ($status === 'accepted') {
                    return sprintf(__('Validation accepted by %s', 'glpipwa'), $validator);
                } elseif ($status === 'refused') {
                    return sprintf(__('Validation refused by %s', 'glpipwa'), $validator);
                }
                return sprintf(__('Validation updated by %s', 'glpipwa'), $validator);
            
            case 'task_added':
                $taskName = $payload['task_name'] ?? __('Task', 'glpipwa');
                $creator = $payload['creator_name'] ?? __('User', 'glpipwa');
                return sprintf(__('%s added task: %s', 'glpipwa'), $creator, $taskName);
            
            default:
                return __('An event occurred on this ticket', 'glpipwa');
        }
    }

    /**
     * Obtém URL completa do ticket
     * 
     * @param int $ticketId ID do ticket
     * @return string URL completa
     */
    private static function getTicketUrl(int $ticketId): string
    {
        if (!class_exists('Ticket')) {
            return '';
        }

        try {
            $ticket = new Ticket();
            if (!$ticket->getFromDB($ticketId)) {
                return '';
            }

            $url = $ticket->getLinkURL();
            
            // Se a URL não for absoluta, construir URL completa
            if (!empty($url) && !preg_match('/^https?:\/\//', $url)) {
                global $CFG_GLPI;
                if (isset($CFG_GLPI['url_base']) && !empty($CFG_GLPI['url_base'])) {
                    $baseUrl = rtrim($CFG_GLPI['url_base'], '/');
                    $url = $baseUrl . '/' . ltrim($url, '/');
                }
            }
            
            return $url;
        } catch (Exception $e) {
            self::log('warning', "Erro ao obter URL do ticket: " . $e->getMessage());
            return '';
        }
    }

    /**
     * Valida se um valor é um ID de usuário válido
     * 
     * @param mixed $user_id Valor a ser validado
     * @return bool True se for válido
     */
    private static function isValidUserId($user_id): bool
    {
        if (!is_numeric($user_id)) {
            return false;
        }
        
        $user_id = (int)$user_id;
        return $user_id > 0;
    }

    /**
     * Filtra e valida um array de IDs de usuários
     * 
     * @param array $user_ids Array de IDs
     * @return array Array com IDs válidos
     */
    private static function filterValidUserIds(array $user_ids): array
    {
        $valid_ids = [];
        foreach ($user_ids as $id) {
            if (self::isValidUserId($id)) {
                $valid_ids[] = (int)$id;
            }
        }
        return array_unique($valid_ids);
    }

    /**
     * Obtém o valor de uma constante de tipo de ator de forma segura
     * 
     * @param string $constantName Nome da constante (REQUESTER, ASSIGN, OBSERVER)
     * @return int|null Valor da constante ou null se não existir
     */
    private static function getActorTypeConstant(string $constantName): ?int
    {
        if (!class_exists('CommonITILActor')) {
            self::log('debug', "Classe CommonITILActor não existe, usando valores padrão");
            return null;
        }

        try {
            // Tentar diferentes variações do nome da constante
            $constantVariations = [];
            
            if ($constantName === 'ASSIGN') {
                // ASSIGN pode estar como ASSIGN ou ASSIGNED
                $constantVariations = ['ASSIGN', 'ASSIGNED'];
            } else {
                $constantVariations = [$constantName];
            }

            foreach ($constantVariations as $variation) {
                $fullConstantName = "CommonITILActor::{$variation}";
                if (defined($fullConstantName)) {
                    $value = constant($fullConstantName);
                    self::log('debug', "Constante {$fullConstantName} encontrada com valor: {$value}");
                    return (int)$value;
                }
                
                // Tentar usando reflexão como fallback
                try {
                    $reflection = new ReflectionClass('CommonITILActor');
                    if ($reflection->hasConstant($variation)) {
                        $value = $reflection->getConstant($variation);
                        self::log('debug', "Constante {$variation} encontrada via reflexão com valor: {$value}");
                        return (int)$value;
                    }
                } catch (ReflectionException $e) {
                    // Continuar tentando
                }
            }

            self::log('warning', "Constante CommonITILActor::{$constantName} não encontrada (tentativas: " . implode(', ', $constantVariations) . ")");
            return null;
        } catch (Exception $e) {
            self::log('warning', "Erro ao obter constante CommonITILActor::{$constantName}: " . $e->getMessage());
            return null;
        } catch (Throwable $e) {
            self::log('error', "Erro fatal ao obter constante CommonITILActor::{$constantName}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Registra log em arquivo próprio
     * 
     * @param string $level Nível do log (debug, info, warning, error)
     * @param string $message Mensagem do log
     * @param array $context Contexto adicional
     * @return void
     */
    private static function log(string $level, string $message, array $context = []): void
    {
        try {
            // Diretório de logs do GLPI
            $logDir = GLPI_ROOT . '/files/_log';
            
            // Garantir que o diretório existe
            if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
                // Se não conseguir criar, usar Toolbox como fallback
                if (class_exists('Toolbox')) {
                    Toolbox::logInFile('glpipwa', "GLPI PWA NotificationService: " . $message, LOG_DEBUG);
                }
                return;
            }

            $logFile = $logDir . '/' . self::LOG_FILE;
            
            // Formatar mensagem
            $timestamp = date('Y-m-d H:i:s');
            $levelUpper = strtoupper($level);
            $contextStr = !empty($context) ? ' ' . json_encode($context) : '';
            $logMessage = "[{$timestamp}] [{$levelUpper}] {$message}{$contextStr}" . PHP_EOL;
            
            // Escrever no arquivo (append)
            file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
            
            // Também usar Toolbox para logs de erro/warning
            if ($level === 'error' || $level === 'warning') {
                if (class_exists('Toolbox')) {
                    if ($level === 'error') {
                        Toolbox::logInFile('glpipwa', "GLPI PWA NotificationService: " . $message, LOG_ERR);
                    } else {
                        Toolbox::logInFile('glpipwa', "GLPI PWA NotificationService: " . $message, LOG_WARNING);
                    }
                }
            }
        } catch (Exception $e) {
            // Silenciosamente falha no log se não conseguir escrever
            // Não queremos que erro de log quebre a notificação
        } catch (Throwable $e) {
            // Ignorar erros fatais no log também
        }
    }
}

